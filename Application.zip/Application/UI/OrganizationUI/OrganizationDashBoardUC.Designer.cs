﻿namespace Farmer_Representive_Final_Project_DB_.UI.OrganizationUI
{
    partial class OrganizationDashBoardUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrganizationDashBoardUC));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2VProgressBar1 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar2 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar3 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar4 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar5 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar6 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.advisorCount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elipsePanel = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.PnlWallet = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2VProgressBar19 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar20 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar21 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar22 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar23 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar24 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2VProgressBar7 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar8 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar9 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar10 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar11 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar12 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2VProgressBar13 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar14 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar15 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar16 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar17 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2VProgressBar18 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.elipseDashBoard = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse6 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse7 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.gridPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.Panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlWallet)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.Panel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            this.Panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.Panel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.gridPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this.Panel1;
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel1.BorderThickness = 1;
            this.Panel1.Controls.Add(this.tableLayoutPanel1);
            this.Panel1.Controls.Add(this.guna2PictureBox2);
            this.Panel1.Controls.Add(this.advisorCount);
            this.Panel1.Controls.Add(this.guna2HtmlLabel8);
            this.Panel1.Location = new System.Drawing.Point(3, 3);
            this.Panel1.MaximumSize = new System.Drawing.Size(256, 203);
            this.Panel1.MinimumSize = new System.Drawing.Size(154, 76);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(255, 203);
            this.Panel1.TabIndex = 5;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.90909F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.09091F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2VProgressBar6, 5, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 91);
            this.tableLayoutPanel1.MaximumSize = new System.Drawing.Size(250, 100);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(162, 100);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // guna2VProgressBar1
            // 
            this.guna2VProgressBar1.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar1.BorderRadius = 6;
            this.guna2VProgressBar1.BorderThickness = 1;
            this.guna2VProgressBar1.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar1.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar1.Location = new System.Drawing.Point(3, 3);
            this.guna2VProgressBar1.Name = "guna2VProgressBar1";
            this.guna2VProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar1.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar1.Size = new System.Drawing.Size(18, 94);
            this.guna2VProgressBar1.TabIndex = 0;
            this.guna2VProgressBar1.Text = "guna2VProgressBar1";
            this.guna2VProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar1.Value = 30;
            // 
            // guna2VProgressBar2
            // 
            this.guna2VProgressBar2.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar2.BorderRadius = 6;
            this.guna2VProgressBar2.BorderThickness = 1;
            this.guna2VProgressBar2.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar2.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar2.Location = new System.Drawing.Point(27, 3);
            this.guna2VProgressBar2.Name = "guna2VProgressBar2";
            this.guna2VProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar2.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar2.Size = new System.Drawing.Size(18, 94);
            this.guna2VProgressBar2.TabIndex = 0;
            this.guna2VProgressBar2.Text = "guna2VProgressBar1";
            this.guna2VProgressBar2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar2.Value = 80;
            // 
            // guna2VProgressBar3
            // 
            this.guna2VProgressBar3.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar3.BorderRadius = 6;
            this.guna2VProgressBar3.BorderThickness = 1;
            this.guna2VProgressBar3.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar3.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar3.Location = new System.Drawing.Point(51, 3);
            this.guna2VProgressBar3.Name = "guna2VProgressBar3";
            this.guna2VProgressBar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar3.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar3.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar3.TabIndex = 0;
            this.guna2VProgressBar3.Text = "guna2VProgressBar1";
            this.guna2VProgressBar3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar3.Value = 70;
            // 
            // guna2VProgressBar4
            // 
            this.guna2VProgressBar4.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar4.BorderRadius = 6;
            this.guna2VProgressBar4.BorderThickness = 1;
            this.guna2VProgressBar4.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar4.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar4.Location = new System.Drawing.Point(81, 3);
            this.guna2VProgressBar4.Name = "guna2VProgressBar4";
            this.guna2VProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar4.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar4.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar4.TabIndex = 0;
            this.guna2VProgressBar4.Text = "guna2VProgressBar1";
            this.guna2VProgressBar4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar4.Value = 60;
            // 
            // guna2VProgressBar5
            // 
            this.guna2VProgressBar5.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar5.BorderRadius = 6;
            this.guna2VProgressBar5.BorderThickness = 1;
            this.guna2VProgressBar5.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar5.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar5.Location = new System.Drawing.Point(108, 3);
            this.guna2VProgressBar5.Name = "guna2VProgressBar5";
            this.guna2VProgressBar5.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar5.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar5.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar5.TabIndex = 0;
            this.guna2VProgressBar5.Text = "guna2VProgressBar1";
            this.guna2VProgressBar5.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar5.Value = 100;
            // 
            // guna2VProgressBar6
            // 
            this.guna2VProgressBar6.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar6.BorderRadius = 6;
            this.guna2VProgressBar6.BorderThickness = 1;
            this.guna2VProgressBar6.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar6.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar6.Location = new System.Drawing.Point(134, 3);
            this.guna2VProgressBar6.Name = "guna2VProgressBar6";
            this.guna2VProgressBar6.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar6.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar6.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar6.TabIndex = 0;
            this.guna2VProgressBar6.Text = "guna2VProgressBar1";
            this.guna2VProgressBar6.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar6.Value = 50;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.Image")));
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(222, 6);
            this.guna2PictureBox2.MaximumSize = new System.Drawing.Size(65, 57);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(27, 31);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 0;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.UseTransparentBackground = true;
            // 
            // advisorCount
            // 
            this.advisorCount.BackColor = System.Drawing.Color.Transparent;
            this.advisorCount.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advisorCount.ForeColor = System.Drawing.Color.White;
            this.advisorCount.Location = new System.Drawing.Point(12, 40);
            this.advisorCount.Name = "advisorCount";
            this.advisorCount.Size = new System.Drawing.Size(55, 33);
            this.advisorCount.TabIndex = 1;
            this.advisorCount.Text = "2000";
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(12, 3);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(58, 33);
            this.guna2HtmlLabel8.TabIndex = 1;
            this.guna2HtmlLabel8.Text = "Alert";
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.MinimumWidth = 8;
            this.Email.Name = "Email";
            // 
            // DOB
            // 
            this.DOB.HeaderText = "DOB";
            this.DOB.MinimumWidth = 8;
            this.DOB.Name = "DOB";
            // 
            // Gender
            // 
            this.Gender.HeaderText = "Gender";
            this.Gender.MinimumWidth = 8;
            this.Gender.Name = "Gender";
            // 
            // elipsePanel
            // 
            this.elipsePanel.BorderRadius = 10;
            this.elipsePanel.TargetControl = this.PnlWallet;
            // 
            // PnlWallet
            // 
            this.PnlWallet.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            this.PnlWallet.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PnlWallet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.PnlWallet.ColumnHeadersHeight = 37;
            this.PnlWallet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.PnlWallet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Delete,
            this.EmployeeID,
            this.FirstName,
            this.LastName,
            this.Email,
            this.DOB,
            this.Gender});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PnlWallet.DefaultCellStyle = dataGridViewCellStyle7;
            this.PnlWallet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlWallet.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.PnlWallet.Location = new System.Drawing.Point(0, 0);
            this.PnlWallet.Name = "PnlWallet";
            this.PnlWallet.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PnlWallet.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.PnlWallet.RowHeadersVisible = false;
            this.PnlWallet.RowHeadersWidth = 62;
            this.PnlWallet.RowTemplate.Height = 28;
            this.PnlWallet.Size = new System.Drawing.Size(1376, 555);
            this.PnlWallet.TabIndex = 1;
            this.PnlWallet.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            this.PnlWallet.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PnlWallet.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.PnlWallet.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Gray;
            this.PnlWallet.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.PnlWallet.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.PnlWallet.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.PnlWallet.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.PnlWallet.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.PnlWallet.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PnlWallet.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.PnlWallet.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.PnlWallet.ThemeStyle.HeaderStyle.Height = 37;
            this.PnlWallet.ThemeStyle.ReadOnly = false;
            this.PnlWallet.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(229)))), ((int)(((byte)(221)))));
            this.PnlWallet.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.PnlWallet.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PnlWallet.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(72)))), ((int)(((byte)(72)))));
            this.PnlWallet.ThemeStyle.RowsStyle.Height = 28;
            this.PnlWallet.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Gray;
            this.PnlWallet.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.Image = ((System.Drawing.Image)(resources.GetObject("Delete.Image")));
            this.Delete.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Delete.MinimumWidth = 8;
            this.Delete.Name = "Delete";
            this.Delete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // EmployeeID
            // 
            this.EmployeeID.HeaderText = "EmployeeID";
            this.EmployeeID.MinimumWidth = 8;
            this.EmployeeID.Name = "EmployeeID";
            // 
            // FirstName
            // 
            this.FirstName.HeaderText = "First Name";
            this.FirstName.MinimumWidth = 8;
            this.FirstName.Name = "FirstName";
            // 
            // LastName
            // 
            this.LastName.HeaderText = "Last Name";
            this.LastName.MinimumWidth = 8;
            this.LastName.Name = "LastName";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(47, 14);
            this.tableLayoutPanel6.MaximumSize = new System.Drawing.Size(120, 209);
            this.tableLayoutPanel6.MinimumSize = new System.Drawing.Size(44, 76);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(120, 206);
            this.tableLayoutPanel6.TabIndex = 49;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.BorderRadius = 30;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(114, 200);
            this.panel5.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.AutoScroll = true;
            this.tableLayoutPanel2.ColumnCount = 8;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.44444F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.44444F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.525279F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.06667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.6F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 134F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel2.Controls.Add(this.panel6, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.Panel4, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.Panel2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.Panel3, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.Panel1, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(189, 11);
            this.tableLayoutPanel2.MaximumSize = new System.Drawing.Size(1343, 209);
            this.tableLayoutPanel2.MinimumSize = new System.Drawing.Size(905, 76);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1343, 209);
            this.tableLayoutPanel2.TabIndex = 48;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel6.BorderRadius = 30;
            this.panel6.Location = new System.Drawing.Point(1079, 3);
            this.panel6.MaximumSize = new System.Drawing.Size(120, 209);
            this.panel6.MinimumSize = new System.Drawing.Size(44, 76);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(120, 203);
            this.panel6.TabIndex = 3;
            // 
            // Panel4
            // 
            this.Panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel4.BorderThickness = 1;
            this.Panel4.Controls.Add(this.tableLayoutPanel5);
            this.Panel4.Controls.Add(this.guna2PictureBox4);
            this.Panel4.Controls.Add(this.guna2HtmlLabel6);
            this.Panel4.Controls.Add(this.guna2HtmlLabel7);
            this.Panel4.Location = new System.Drawing.Point(530, 3);
            this.Panel4.MaximumSize = new System.Drawing.Size(256, 203);
            this.Panel4.MinimumSize = new System.Drawing.Size(154, 76);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(256, 203);
            this.Panel4.TabIndex = 5;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel5.ColumnCount = 6;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.90909F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.09091F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar19, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar20, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar21, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar22, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar23, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.guna2VProgressBar24, 5, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(12, 94);
            this.tableLayoutPanel5.MaximumSize = new System.Drawing.Size(250, 100);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(163, 100);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // guna2VProgressBar19
            // 
            this.guna2VProgressBar19.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar19.BorderRadius = 6;
            this.guna2VProgressBar19.BorderThickness = 1;
            this.guna2VProgressBar19.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar19.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar19.Location = new System.Drawing.Point(3, 3);
            this.guna2VProgressBar19.Name = "guna2VProgressBar19";
            this.guna2VProgressBar19.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar19.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar19.Size = new System.Drawing.Size(19, 94);
            this.guna2VProgressBar19.TabIndex = 0;
            this.guna2VProgressBar19.Text = "guna2VProgressBar1";
            this.guna2VProgressBar19.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar19.Value = 30;
            // 
            // guna2VProgressBar20
            // 
            this.guna2VProgressBar20.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar20.BorderRadius = 6;
            this.guna2VProgressBar20.BorderThickness = 1;
            this.guna2VProgressBar20.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar20.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar20.Location = new System.Drawing.Point(28, 3);
            this.guna2VProgressBar20.Name = "guna2VProgressBar20";
            this.guna2VProgressBar20.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar20.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar20.Size = new System.Drawing.Size(18, 94);
            this.guna2VProgressBar20.TabIndex = 0;
            this.guna2VProgressBar20.Text = "guna2VProgressBar1";
            this.guna2VProgressBar20.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar20.Value = 80;
            // 
            // guna2VProgressBar21
            // 
            this.guna2VProgressBar21.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar21.BorderRadius = 6;
            this.guna2VProgressBar21.BorderThickness = 1;
            this.guna2VProgressBar21.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar21.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar21.Location = new System.Drawing.Point(52, 3);
            this.guna2VProgressBar21.Name = "guna2VProgressBar21";
            this.guna2VProgressBar21.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar21.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar21.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar21.TabIndex = 0;
            this.guna2VProgressBar21.Text = "guna2VProgressBar1";
            this.guna2VProgressBar21.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar21.Value = 70;
            // 
            // guna2VProgressBar22
            // 
            this.guna2VProgressBar22.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar22.BorderRadius = 6;
            this.guna2VProgressBar22.BorderThickness = 1;
            this.guna2VProgressBar22.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar22.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar22.Location = new System.Drawing.Point(82, 3);
            this.guna2VProgressBar22.Name = "guna2VProgressBar22";
            this.guna2VProgressBar22.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar22.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar22.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar22.TabIndex = 0;
            this.guna2VProgressBar22.Text = "guna2VProgressBar1";
            this.guna2VProgressBar22.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar22.Value = 60;
            // 
            // guna2VProgressBar23
            // 
            this.guna2VProgressBar23.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar23.BorderRadius = 6;
            this.guna2VProgressBar23.BorderThickness = 1;
            this.guna2VProgressBar23.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar23.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar23.Location = new System.Drawing.Point(109, 3);
            this.guna2VProgressBar23.Name = "guna2VProgressBar23";
            this.guna2VProgressBar23.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar23.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar23.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar23.TabIndex = 0;
            this.guna2VProgressBar23.Text = "guna2VProgressBar1";
            this.guna2VProgressBar23.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar23.Value = 100;
            // 
            // guna2VProgressBar24
            // 
            this.guna2VProgressBar24.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar24.BorderRadius = 6;
            this.guna2VProgressBar24.BorderThickness = 1;
            this.guna2VProgressBar24.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar24.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar24.Location = new System.Drawing.Point(135, 3);
            this.guna2VProgressBar24.Name = "guna2VProgressBar24";
            this.guna2VProgressBar24.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar24.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar24.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar24.TabIndex = 0;
            this.guna2VProgressBar24.Text = "guna2VProgressBar1";
            this.guna2VProgressBar24.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar24.Value = 50;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox4.Image")));
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(223, 6);
            this.guna2PictureBox4.MaximumSize = new System.Drawing.Size(65, 57);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(27, 31);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox4.TabIndex = 0;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.UseTransparentBackground = true;
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(12, 40);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(42, 33);
            this.guna2HtmlLabel6.TabIndex = 1;
            this.guna2HtmlLabel6.Text = "130";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(12, 3);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(168, 33);
            this.guna2HtmlLabel7.TabIndex = 1;
            this.guna2HtmlLabel7.Text = "Pending Orders";
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel2.BorderThickness = 1;
            this.Panel2.Controls.Add(this.tableLayoutPanel3);
            this.Panel2.Controls.Add(this.guna2PictureBox1);
            this.Panel2.Controls.Add(this.guna2HtmlLabel1);
            this.Panel2.Controls.Add(this.guna2HtmlLabel3);
            this.Panel2.Location = new System.Drawing.Point(264, 3);
            this.Panel2.MaximumSize = new System.Drawing.Size(256, 203);
            this.Panel2.MinimumSize = new System.Drawing.Size(154, 76);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(244, 203);
            this.Panel2.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.09091F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.90909F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar7, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar8, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar9, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar10, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar11, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.guna2VProgressBar12, 5, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 94);
            this.tableLayoutPanel3.MaximumSize = new System.Drawing.Size(250, 100);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(164, 100);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // guna2VProgressBar7
            // 
            this.guna2VProgressBar7.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar7.BorderRadius = 6;
            this.guna2VProgressBar7.BorderThickness = 1;
            this.guna2VProgressBar7.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar7.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar7.Location = new System.Drawing.Point(3, 3);
            this.guna2VProgressBar7.Name = "guna2VProgressBar7";
            this.guna2VProgressBar7.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar7.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar7.Size = new System.Drawing.Size(19, 94);
            this.guna2VProgressBar7.TabIndex = 0;
            this.guna2VProgressBar7.Text = "guna2VProgressBar1";
            this.guna2VProgressBar7.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar7.Value = 30;
            // 
            // guna2VProgressBar8
            // 
            this.guna2VProgressBar8.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar8.BorderRadius = 6;
            this.guna2VProgressBar8.BorderThickness = 1;
            this.guna2VProgressBar8.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar8.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar8.Location = new System.Drawing.Point(28, 3);
            this.guna2VProgressBar8.Name = "guna2VProgressBar8";
            this.guna2VProgressBar8.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar8.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar8.Size = new System.Drawing.Size(19, 94);
            this.guna2VProgressBar8.TabIndex = 0;
            this.guna2VProgressBar8.Text = "guna2VProgressBar1";
            this.guna2VProgressBar8.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar8.Value = 80;
            // 
            // guna2VProgressBar9
            // 
            this.guna2VProgressBar9.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar9.BorderRadius = 6;
            this.guna2VProgressBar9.BorderThickness = 1;
            this.guna2VProgressBar9.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar9.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar9.Location = new System.Drawing.Point(53, 3);
            this.guna2VProgressBar9.Name = "guna2VProgressBar9";
            this.guna2VProgressBar9.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar9.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar9.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar9.TabIndex = 0;
            this.guna2VProgressBar9.Text = "guna2VProgressBar1";
            this.guna2VProgressBar9.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar9.Value = 70;
            // 
            // guna2VProgressBar10
            // 
            this.guna2VProgressBar10.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar10.BorderRadius = 6;
            this.guna2VProgressBar10.BorderThickness = 1;
            this.guna2VProgressBar10.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar10.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar10.Location = new System.Drawing.Point(83, 3);
            this.guna2VProgressBar10.Name = "guna2VProgressBar10";
            this.guna2VProgressBar10.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar10.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar10.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar10.TabIndex = 0;
            this.guna2VProgressBar10.Text = "guna2VProgressBar1";
            this.guna2VProgressBar10.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar10.Value = 60;
            // 
            // guna2VProgressBar11
            // 
            this.guna2VProgressBar11.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar11.BorderRadius = 6;
            this.guna2VProgressBar11.BorderThickness = 1;
            this.guna2VProgressBar11.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar11.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar11.Location = new System.Drawing.Point(110, 3);
            this.guna2VProgressBar11.Name = "guna2VProgressBar11";
            this.guna2VProgressBar11.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar11.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar11.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar11.TabIndex = 0;
            this.guna2VProgressBar11.Text = "guna2VProgressBar1";
            this.guna2VProgressBar11.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar11.Value = 100;
            // 
            // guna2VProgressBar12
            // 
            this.guna2VProgressBar12.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar12.BorderRadius = 6;
            this.guna2VProgressBar12.BorderThickness = 1;
            this.guna2VProgressBar12.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar12.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar12.Location = new System.Drawing.Point(136, 3);
            this.guna2VProgressBar12.Name = "guna2VProgressBar12";
            this.guna2VProgressBar12.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar12.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar12.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar12.TabIndex = 0;
            this.guna2VProgressBar12.Text = "guna2VProgressBar12";
            this.guna2VProgressBar12.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar12.Value = 50;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(211, 6);
            this.guna2PictureBox1.MaximumSize = new System.Drawing.Size(65, 57);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(27, 31);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(12, 43);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(29, 33);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "20";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(12, 6);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(186, 33);
            this.guna2HtmlLabel3.TabIndex = 1;
            this.guna2HtmlLabel3.Text = "Accepted Orders";
            // 
            // Panel3
            // 
            this.Panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.Panel3.BorderThickness = 1;
            this.Panel3.Controls.Add(this.tableLayoutPanel4);
            this.Panel3.Controls.Add(this.guna2PictureBox3);
            this.Panel3.Controls.Add(this.guna2HtmlLabel4);
            this.Panel3.Controls.Add(this.guna2HtmlLabel5);
            this.Panel3.Location = new System.Drawing.Point(798, 3);
            this.Panel3.MaximumSize = new System.Drawing.Size(256, 203);
            this.Panel3.MinimumSize = new System.Drawing.Size(154, 76);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(256, 203);
            this.Panel3.TabIndex = 5;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.90909F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.09091F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar13, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar14, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar15, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar16, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar17, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.guna2VProgressBar18, 5, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(12, 91);
            this.tableLayoutPanel4.MaximumSize = new System.Drawing.Size(250, 100);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(163, 100);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // guna2VProgressBar13
            // 
            this.guna2VProgressBar13.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar13.BorderRadius = 6;
            this.guna2VProgressBar13.BorderThickness = 1;
            this.guna2VProgressBar13.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar13.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar13.Location = new System.Drawing.Point(3, 3);
            this.guna2VProgressBar13.Name = "guna2VProgressBar13";
            this.guna2VProgressBar13.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar13.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar13.Size = new System.Drawing.Size(19, 94);
            this.guna2VProgressBar13.TabIndex = 0;
            this.guna2VProgressBar13.Text = "guna2VProgressBar1";
            this.guna2VProgressBar13.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar13.Value = 30;
            // 
            // guna2VProgressBar14
            // 
            this.guna2VProgressBar14.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar14.BorderRadius = 6;
            this.guna2VProgressBar14.BorderThickness = 1;
            this.guna2VProgressBar14.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar14.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar14.Location = new System.Drawing.Point(28, 3);
            this.guna2VProgressBar14.Name = "guna2VProgressBar14";
            this.guna2VProgressBar14.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar14.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar14.Size = new System.Drawing.Size(18, 94);
            this.guna2VProgressBar14.TabIndex = 0;
            this.guna2VProgressBar14.Text = "guna2VProgressBar1";
            this.guna2VProgressBar14.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar14.Value = 80;
            // 
            // guna2VProgressBar15
            // 
            this.guna2VProgressBar15.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar15.BorderRadius = 6;
            this.guna2VProgressBar15.BorderThickness = 1;
            this.guna2VProgressBar15.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar15.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar15.Location = new System.Drawing.Point(52, 3);
            this.guna2VProgressBar15.Name = "guna2VProgressBar15";
            this.guna2VProgressBar15.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar15.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar15.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar15.TabIndex = 0;
            this.guna2VProgressBar15.Text = "guna2VProgressBar1";
            this.guna2VProgressBar15.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar15.Value = 70;
            // 
            // guna2VProgressBar16
            // 
            this.guna2VProgressBar16.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar16.BorderRadius = 6;
            this.guna2VProgressBar16.BorderThickness = 1;
            this.guna2VProgressBar16.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar16.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar16.Location = new System.Drawing.Point(82, 3);
            this.guna2VProgressBar16.Name = "guna2VProgressBar16";
            this.guna2VProgressBar16.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar16.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar16.Size = new System.Drawing.Size(21, 94);
            this.guna2VProgressBar16.TabIndex = 0;
            this.guna2VProgressBar16.Text = "guna2VProgressBar1";
            this.guna2VProgressBar16.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar16.Value = 60;
            // 
            // guna2VProgressBar17
            // 
            this.guna2VProgressBar17.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar17.BorderRadius = 6;
            this.guna2VProgressBar17.BorderThickness = 1;
            this.guna2VProgressBar17.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar17.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar17.Location = new System.Drawing.Point(109, 3);
            this.guna2VProgressBar17.Name = "guna2VProgressBar17";
            this.guna2VProgressBar17.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar17.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar17.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar17.TabIndex = 0;
            this.guna2VProgressBar17.Text = "guna2VProgressBar1";
            this.guna2VProgressBar17.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar17.Value = 100;
            // 
            // guna2VProgressBar18
            // 
            this.guna2VProgressBar18.BorderColor = System.Drawing.Color.White;
            this.guna2VProgressBar18.BorderRadius = 6;
            this.guna2VProgressBar18.BorderThickness = 1;
            this.guna2VProgressBar18.FillColor = System.Drawing.Color.White;
            this.guna2VProgressBar18.ForeColor = System.Drawing.Color.White;
            this.guna2VProgressBar18.Location = new System.Drawing.Point(135, 3);
            this.guna2VProgressBar18.Name = "guna2VProgressBar18";
            this.guna2VProgressBar18.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.guna2VProgressBar18.ProgressColor2 = System.Drawing.Color.White;
            this.guna2VProgressBar18.Size = new System.Drawing.Size(20, 94);
            this.guna2VProgressBar18.TabIndex = 0;
            this.guna2VProgressBar18.Text = "guna2VProgressBar1";
            this.guna2VProgressBar18.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar18.Value = 50;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(223, 6);
            this.guna2PictureBox3.MaximumSize = new System.Drawing.Size(65, 57);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(27, 31);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox3.TabIndex = 0;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.UseTransparentBackground = true;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(15, 43);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(57, 33);
            this.guna2HtmlLabel4.TabIndex = 1;
            this.guna2HtmlLabel4.Text = "$100";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Comic Sans MS", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(12, 3);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(113, 33);
            this.guna2HtmlLabel5.TabIndex = 1;
            this.guna2HtmlLabel5.Text = "My Wallet";
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.BorderRadius = 20;
            this.guna2Elipse3.TargetControl = this.Panel3;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(47, 387);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(204, 42);
            this.guna2HtmlLabel2.TabIndex = 47;
            this.guna2HtmlLabel2.Text = "Pending Requests";
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 20;
            this.guna2Elipse2.TargetControl = this.Panel2;
            // 
            // elipseDashBoard
            // 
            this.elipseDashBoard.BorderRadius = 10;
            this.elipseDashBoard.TargetControl = this;
            // 
            // guna2Elipse4
            // 
            this.guna2Elipse4.BorderRadius = 20;
            this.guna2Elipse4.TargetControl = this.Panel4;
            // 
            // guna2Elipse5
            // 
            this.guna2Elipse5.BorderRadius = 20;
            this.guna2Elipse5.TargetControl = this.panel5;
            // 
            // guna2Elipse6
            // 
            this.guna2Elipse6.BorderRadius = 20;
            this.guna2Elipse6.TargetControl = this.panel6;
            // 
            // guna2Elipse7
            // 
            this.guna2Elipse7.BorderRadius = 20;
            this.guna2Elipse7.TargetControl = this.gridPanel;
            // 
            // gridPanel
            // 
            this.gridPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridPanel.BackColor = System.Drawing.Color.White;
            this.gridPanel.BorderColor = System.Drawing.Color.White;
            this.gridPanel.Controls.Add(this.PnlWallet);
            this.gridPanel.Location = new System.Drawing.Point(47, 435);
            this.gridPanel.MaximumSize = new System.Drawing.Size(1376, 555);
            this.gridPanel.MinimumSize = new System.Drawing.Size(300, 300);
            this.gridPanel.Name = "gridPanel";
            this.gridPanel.Size = new System.Drawing.Size(1376, 555);
            this.gridPanel.TabIndex = 50;
            // 
            // OrganizationDashBoardUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tableLayoutPanel6);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.gridPanel);
            this.Name = "OrganizationDashBoardUC";
            this.Size = new System.Drawing.Size(1579, 1000);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PnlWallet)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.Panel4.ResumeLayout(false);
            this.Panel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.Panel3.ResumeLayout(false);
            this.Panel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.gridPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel Panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar1;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar2;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar3;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar4;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar5;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel advisorCount;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gender;
        private Guna.UI2.WinForms.Guna2Elipse elipsePanel;
        private Guna.UI2.WinForms.Guna2DataGridView PnlWallet;
        private System.Windows.Forms.DataGridViewImageColumn Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private Guna.UI2.WinForms.Guna2Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Guna.UI2.WinForms.Guna2Panel panel6;
        private Guna.UI2.WinForms.Guna2Panel Panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar19;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar20;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar21;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar22;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar23;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar24;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2Panel Panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar7;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar8;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar9;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar10;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar11;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar12;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2Panel Panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar13;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar14;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar15;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar16;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar17;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar18;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse elipseDashBoard;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse6;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse7;
        private Guna.UI2.WinForms.Guna2Panel gridPanel;
    }
}
