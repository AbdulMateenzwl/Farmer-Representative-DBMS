﻿namespace Farmer_Representive_Final_Project_DB_
{
    partial class FarmerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FarmerForm));
            this.panelMainMenu = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.btnSettings = new Guna.UI2.WinForms.Guna2Button();
            this.btnWallet = new Guna.UI2.WinForms.Guna2Button();
            this.btnManageCrops = new Guna.UI2.WinForms.Guna2Button();
            this.panelManagePpl = new Guna.UI2.WinForms.Guna2Panel();
            this.btnManageAdvisor = new Guna.UI2.WinForms.Guna2Button();
            this.ManageStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnManageField = new Guna.UI2.WinForms.Guna2Button();
            this.sidePanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btnHome = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.elipseMenuPanel = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.ResizeFarmerForm = new Guna.UI2.WinForms.Guna2ResizeForm(this.components);
            this.closeBtnFarmer = new Guna.UI2.WinForms.Guna2ImageButton();
            this.maxBtnFarmer = new Guna.UI2.WinForms.Guna2ImageButton();
            this.minBtnFarmer = new Guna.UI2.WinForms.Guna2ImageButton();
            this.maxBtnFamer = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.btnSubscription = new Guna.UI2.WinForms.Guna2Button();
            this.subscription1 = new Farmer_Representive_Final_Project_DB_.UI.Components.Subscription();
            this.changeAccount1 = new Farmer_Representive_Final_Project_DB_.UI.FarmerUI.changeAccount();
            this.dashBoard1 = new Farmer_Representive_Final_Project_DB_.UI.FarmerUI.DashBoard();
            this.walletPnl1 = new Farmer_Representive_Final_Project_DB_.UI.FarmerUI.walletPnl();
            this.cropsCrud1 = new Farmer_Representive_Final_Project_DB_.UI.FarmerUI.CropsCrud();
            this.fieldCrud1 = new Farmer_Representive_Final_Project_DB_.UI.FarmerUI.FieldCrud();
            this.btnReports = new Guna.UI2.WinForms.Guna2Button();
            this.reports1 = new Farmer_Representive_Final_Project_DB_.UI.Components.Reports();
            this.panelMainMenu.SuspendLayout();
            this.panelManagePpl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.maxBtnFamer.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMainMenu
            // 
            this.panelMainMenu.AccessibleName = "MenuPanel";
            this.panelMainMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelMainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.panelMainMenu.Controls.Add(this.btnReports);
            this.panelMainMenu.Controls.Add(this.btnSettings);
            this.panelMainMenu.Controls.Add(this.btnSubscription);
            this.panelMainMenu.Controls.Add(this.btnWallet);
            this.panelMainMenu.Controls.Add(this.btnManageCrops);
            this.panelMainMenu.Controls.Add(this.panelManagePpl);
            this.panelMainMenu.Controls.Add(this.btnManageField);
            this.panelMainMenu.Controls.Add(this.sidePanel);
            this.panelMainMenu.Controls.Add(this.guna2PictureBox1);
            this.panelMainMenu.Controls.Add(this.btnHome);
            this.panelMainMenu.Controls.Add(this.guna2HtmlLabel2);
            this.panelMainMenu.Controls.Add(this.guna2HtmlLabel1);
            this.panelMainMenu.Location = new System.Drawing.Point(0, 1);
            this.panelMainMenu.MaximumSize = new System.Drawing.Size(320, 1200);
            this.panelMainMenu.MinimumSize = new System.Drawing.Size(90, 700);
            this.panelMainMenu.Name = "panelMainMenu";
            this.panelMainMenu.Size = new System.Drawing.Size(302, 892);
            this.panelMainMenu.TabIndex = 1;
            this.panelMainMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMainMenu_Paint);
            // 
            // btnSettings
            // 
            this.btnSettings.AccessibleName = "";
            this.btnSettings.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettings.Animated = true;
            this.btnSettings.AnimatedGIF = true;
            this.btnSettings.BorderColor = System.Drawing.Color.White;
            this.btnSettings.BorderRadius = 5;
            this.btnSettings.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnSettings.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnSettings.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettings.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnSettings.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnSettings.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnSettings.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnSettings.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnSettings.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnSettings.ForeColor = System.Drawing.Color.White;
            this.btnSettings.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnSettings.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnSettings.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSettings.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnSettings.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnSettings.Image = ((System.Drawing.Image)(resources.GetObject("btnSettings.Image")));
            this.btnSettings.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSettings.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSettings.Location = new System.Drawing.Point(21, 835);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(292, 45);
            this.btnSettings.TabIndex = 6;
            this.btnSettings.Text = " Setting";
            this.btnSettings.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSettings.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnWallet
            // 
            this.btnWallet.AccessibleName = "";
            this.btnWallet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWallet.Animated = true;
            this.btnWallet.AnimatedGIF = true;
            this.btnWallet.BorderColor = System.Drawing.Color.White;
            this.btnWallet.BorderRadius = 5;
            this.btnWallet.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnWallet.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnWallet.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnWallet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWallet.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnWallet.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnWallet.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnWallet.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnWallet.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnWallet.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnWallet.ForeColor = System.Drawing.Color.White;
            this.btnWallet.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnWallet.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnWallet.HoverState.FillColor = System.Drawing.Color.White;
            this.btnWallet.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnWallet.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnWallet.Image = ((System.Drawing.Image)(resources.GetObject("btnWallet.Image")));
            this.btnWallet.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnWallet.ImageSize = new System.Drawing.Size(25, 25);
            this.btnWallet.Location = new System.Drawing.Point(21, 395);
            this.btnWallet.Name = "btnWallet";
            this.btnWallet.Size = new System.Drawing.Size(292, 45);
            this.btnWallet.TabIndex = 6;
            this.btnWallet.Text = "Wallet";
            this.btnWallet.Click += new System.EventHandler(this.btnGroup_Click);
            // 
            // btnManageCrops
            // 
            this.btnManageCrops.AccessibleName = "";
            this.btnManageCrops.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnManageCrops.Animated = true;
            this.btnManageCrops.AnimatedGIF = true;
            this.btnManageCrops.BorderColor = System.Drawing.Color.White;
            this.btnManageCrops.BorderRadius = 5;
            this.btnManageCrops.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnManageCrops.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageCrops.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnManageCrops.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCrops.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnManageCrops.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnManageCrops.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnManageCrops.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnManageCrops.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnManageCrops.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnManageCrops.ForeColor = System.Drawing.Color.White;
            this.btnManageCrops.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnManageCrops.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageCrops.HoverState.FillColor = System.Drawing.Color.White;
            this.btnManageCrops.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnManageCrops.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnManageCrops.Image = ((System.Drawing.Image)(resources.GetObject("btnManageCrops.Image")));
            this.btnManageCrops.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnManageCrops.ImageSize = new System.Drawing.Size(25, 25);
            this.btnManageCrops.Location = new System.Drawing.Point(23, 269);
            this.btnManageCrops.Name = "btnManageCrops";
            this.btnManageCrops.Size = new System.Drawing.Size(292, 45);
            this.btnManageCrops.TabIndex = 6;
            this.btnManageCrops.Text = "     Manage Crops";
            this.btnManageCrops.Click += new System.EventHandler(this.btnProjects_Click);
            // 
            // panelManagePpl
            // 
            this.panelManagePpl.Controls.Add(this.btnManageAdvisor);
            this.panelManagePpl.Controls.Add(this.ManageStudent);
            this.panelManagePpl.Location = new System.Drawing.Point(21, 265);
            this.panelManagePpl.Name = "panelManagePpl";
            this.panelManagePpl.Size = new System.Drawing.Size(274, 0);
            this.panelManagePpl.TabIndex = 5;
            this.panelManagePpl.Paint += new System.Windows.Forms.PaintEventHandler(this.panelManagePpl_Paint);
            // 
            // btnManageAdvisor
            // 
            this.btnManageAdvisor.AccessibleName = "btnMngPpl";
            this.btnManageAdvisor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnManageAdvisor.Animated = true;
            this.btnManageAdvisor.AnimatedGIF = true;
            this.btnManageAdvisor.BorderColor = System.Drawing.Color.White;
            this.btnManageAdvisor.BorderRadius = 5;
            this.btnManageAdvisor.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnManageAdvisor.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageAdvisor.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnManageAdvisor.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnManageAdvisor.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnManageAdvisor.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnManageAdvisor.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnManageAdvisor.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnManageAdvisor.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageAdvisor.ForeColor = System.Drawing.Color.White;
            this.btnManageAdvisor.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnManageAdvisor.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageAdvisor.HoverState.FillColor = System.Drawing.Color.White;
            this.btnManageAdvisor.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnManageAdvisor.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnManageAdvisor.Image = ((System.Drawing.Image)(resources.GetObject("btnManageAdvisor.Image")));
            this.btnManageAdvisor.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnManageAdvisor.Location = new System.Drawing.Point(3, 51);
            this.btnManageAdvisor.Name = "btnManageAdvisor";
            this.btnManageAdvisor.Size = new System.Drawing.Size(268, 45);
            this.btnManageAdvisor.TabIndex = 3;
            this.btnManageAdvisor.Text = "       Manage Advisor";
            this.btnManageAdvisor.Click += new System.EventHandler(this.btnManageAdvisor_Click);
            // 
            // ManageStudent
            // 
            this.ManageStudent.AccessibleName = "btnMngPpl";
            this.ManageStudent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ManageStudent.Animated = true;
            this.ManageStudent.AnimatedGIF = true;
            this.ManageStudent.BorderColor = System.Drawing.Color.White;
            this.ManageStudent.BorderRadius = 5;
            this.ManageStudent.CheckedState.BorderColor = System.Drawing.Color.White;
            this.ManageStudent.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.ManageStudent.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.ManageStudent.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.ManageStudent.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.ManageStudent.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.ManageStudent.DisabledState.ForeColor = System.Drawing.Color.White;
            this.ManageStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.ManageStudent.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageStudent.ForeColor = System.Drawing.Color.White;
            this.ManageStudent.HoverState.BorderColor = System.Drawing.Color.White;
            this.ManageStudent.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.ManageStudent.HoverState.FillColor = System.Drawing.Color.White;
            this.ManageStudent.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.ManageStudent.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.ManageStudent.Image = ((System.Drawing.Image)(resources.GetObject("ManageStudent.Image")));
            this.ManageStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ManageStudent.Location = new System.Drawing.Point(0, 8);
            this.ManageStudent.Name = "ManageStudent";
            this.ManageStudent.Size = new System.Drawing.Size(271, 45);
            this.ManageStudent.TabIndex = 3;
            this.ManageStudent.Text = "        Manage Student";
            this.ManageStudent.Click += new System.EventHandler(this.ManageStudent_Click);
            // 
            // btnManageField
            // 
            this.btnManageField.AccessibleName = "btnMngPpl";
            this.btnManageField.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnManageField.Animated = true;
            this.btnManageField.AnimatedGIF = true;
            this.btnManageField.BorderColor = System.Drawing.Color.White;
            this.btnManageField.BorderRadius = 5;
            this.btnManageField.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnManageField.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageField.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnManageField.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageField.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnManageField.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnManageField.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnManageField.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnManageField.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnManageField.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnManageField.ForeColor = System.Drawing.Color.White;
            this.btnManageField.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnManageField.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnManageField.HoverState.FillColor = System.Drawing.Color.White;
            this.btnManageField.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnManageField.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnManageField.Image = ((System.Drawing.Image)(resources.GetObject("btnManageField.Image")));
            this.btnManageField.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnManageField.ImageSize = new System.Drawing.Size(25, 25);
            this.btnManageField.Location = new System.Drawing.Point(23, 212);
            this.btnManageField.Name = "btnManageField";
            this.btnManageField.Size = new System.Drawing.Size(292, 45);
            this.btnManageField.TabIndex = 3;
            this.btnManageField.Text = "     Manage Fields";
            this.btnManageField.Click += new System.EventHandler(this.btnMngPpl_Click);
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.White;
            this.sidePanel.BorderRadius = 10;
            this.sidePanel.Location = new System.Drawing.Point(0, 148);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(10, 45);
            this.sidePanel.TabIndex = 4;
            this.sidePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.sidePanel_Paint);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BorderRadius = 2;
            this.guna2PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 3);
            this.guna2PictureBox1.MaximumSize = new System.Drawing.Size(94, 83);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(85, 83);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.guna2PictureBox1.TabIndex = 3;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // btnHome
            // 
            this.btnHome.AccessibleName = "btnHome";
            this.btnHome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHome.Animated = true;
            this.btnHome.AnimatedGIF = true;
            this.btnHome.BorderColor = System.Drawing.Color.White;
            this.btnHome.BorderRadius = 5;
            this.btnHome.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnHome.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnHome.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnHome.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnHome.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnHome.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnHome.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnHome.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnHome.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnHome.HoverState.FillColor = System.Drawing.Color.White;
            this.btnHome.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnHome.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnHome.ImageSize = new System.Drawing.Size(25, 25);
            this.btnHome.Location = new System.Drawing.Point(21, 148);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(292, 45);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "   Dash Board";
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AccessibleName = "lblProjectName";
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Comic Sans MS", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(103, 42);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(175, 75);
            this.guna2HtmlLabel2.TabIndex = 1;
            this.guna2HtmlLabel2.Text = "Representative system";
            this.guna2HtmlLabel2.Click += new System.EventHandler(this.guna2HtmlLabel2_Click);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AccessibleName = "lblProjectName";
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(103, 3);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(189, 58);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Farmer";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // elipseMenuPanel
            // 
            this.elipseMenuPanel.BorderRadius = 20;
            this.elipseMenuPanel.TargetControl = this.panelMainMenu;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.DockForm = true;
            this.guna2DragControl1.DockIndicatorColor = System.Drawing.Color.Black;
            this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2DragControl1.TargetControl = this;
            this.guna2DragControl1.UseTransparentDrag = true;
            // 
            // ResizeFarmerForm
            // 
            this.ResizeFarmerForm.TargetForm = this;
            // 
            // closeBtnFarmer
            // 
            this.closeBtnFarmer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBtnFarmer.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.closeBtnFarmer.HoverState.ImageSize = new System.Drawing.Size(10, 10);
            this.closeBtnFarmer.Image = ((System.Drawing.Image)(resources.GetObject("closeBtnFarmer.Image")));
            this.closeBtnFarmer.ImageOffset = new System.Drawing.Point(0, 0);
            this.closeBtnFarmer.ImageRotate = 0F;
            this.closeBtnFarmer.ImageSize = new System.Drawing.Size(20, 20);
            this.closeBtnFarmer.Location = new System.Drawing.Point(1854, 4);
            this.closeBtnFarmer.Name = "closeBtnFarmer";
            this.closeBtnFarmer.Size = new System.Drawing.Size(37, 39);
            this.closeBtnFarmer.TabIndex = 3;
            this.closeBtnFarmer.Click += new System.EventHandler(this.closeBtnFarmer_Click);
            // 
            // maxBtnFarmer
            // 
            this.maxBtnFarmer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maxBtnFarmer.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.maxBtnFarmer.HoverState.ImageSize = new System.Drawing.Size(10, 10);
            this.maxBtnFarmer.Image = ((System.Drawing.Image)(resources.GetObject("maxBtnFarmer.Image")));
            this.maxBtnFarmer.ImageOffset = new System.Drawing.Point(0, 0);
            this.maxBtnFarmer.ImageRotate = 0F;
            this.maxBtnFarmer.ImageSize = new System.Drawing.Size(20, 20);
            this.maxBtnFarmer.Location = new System.Drawing.Point(1811, 4);
            this.maxBtnFarmer.Name = "maxBtnFarmer";
            this.maxBtnFarmer.Size = new System.Drawing.Size(37, 39);
            this.maxBtnFarmer.TabIndex = 3;
            this.maxBtnFarmer.Click += new System.EventHandler(this.maxBtnFarmer_Click);
            // 
            // minBtnFarmer
            // 
            this.minBtnFarmer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.minBtnFarmer.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.minBtnFarmer.HoverState.ImageSize = new System.Drawing.Size(10, 10);
            this.minBtnFarmer.Image = ((System.Drawing.Image)(resources.GetObject("minBtnFarmer.Image")));
            this.minBtnFarmer.ImageOffset = new System.Drawing.Point(0, 0);
            this.minBtnFarmer.ImageRotate = 0F;
            this.minBtnFarmer.ImageSize = new System.Drawing.Size(20, 20);
            this.minBtnFarmer.Location = new System.Drawing.Point(1768, 4);
            this.minBtnFarmer.Name = "minBtnFarmer";
            this.minBtnFarmer.Size = new System.Drawing.Size(37, 39);
            this.minBtnFarmer.TabIndex = 3;
            this.minBtnFarmer.Click += new System.EventHandler(this.minBtnFarmer_Click);
            // 
            // maxBtnFamer
            // 
            this.maxBtnFamer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.maxBtnFamer.Controls.Add(this.reports1);
            this.maxBtnFamer.Controls.Add(this.subscription1);
            this.maxBtnFamer.Controls.Add(this.changeAccount1);
            this.maxBtnFamer.Controls.Add(this.dashBoard1);
            this.maxBtnFamer.Controls.Add(this.walletPnl1);
            this.maxBtnFamer.Controls.Add(this.cropsCrud1);
            this.maxBtnFamer.Controls.Add(this.fieldCrud1);
            this.maxBtnFamer.Location = new System.Drawing.Point(345, 49);
            this.maxBtnFamer.MinimumSize = new System.Drawing.Size(900, 500);
            this.maxBtnFamer.Name = "maxBtnFamer";
            this.maxBtnFamer.Size = new System.Drawing.Size(1544, 832);
            this.maxBtnFamer.TabIndex = 2;
            this.maxBtnFamer.Paint += new System.Windows.Forms.PaintEventHandler(this.maxBtnFamer_Paint);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 15;
            this.guna2Elipse1.TargetControl = this;
            // 
            // btnSubscription
            // 
            this.btnSubscription.AccessibleName = "";
            this.btnSubscription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubscription.Animated = true;
            this.btnSubscription.AnimatedGIF = true;
            this.btnSubscription.BorderColor = System.Drawing.Color.White;
            this.btnSubscription.BorderRadius = 5;
            this.btnSubscription.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnSubscription.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnSubscription.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnSubscription.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubscription.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnSubscription.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnSubscription.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnSubscription.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnSubscription.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnSubscription.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnSubscription.ForeColor = System.Drawing.Color.White;
            this.btnSubscription.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnSubscription.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnSubscription.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSubscription.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnSubscription.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnSubscription.Image = ((System.Drawing.Image)(resources.GetObject("btnSubscription.Image")));
            this.btnSubscription.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSubscription.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSubscription.Location = new System.Drawing.Point(21, 335);
            this.btnSubscription.Name = "btnSubscription";
            this.btnSubscription.Size = new System.Drawing.Size(292, 45);
            this.btnSubscription.TabIndex = 6;
            this.btnSubscription.Text = "    Subscription";
            this.btnSubscription.Click += new System.EventHandler(this.btnSubscription_Click);
            // 
            // subscription1
            // 
            this.subscription1.BackColor = System.Drawing.Color.White;
            this.subscription1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.subscription1.Location = new System.Drawing.Point(0, 0);
            this.subscription1.Name = "subscription1";
            this.subscription1.Size = new System.Drawing.Size(1544, 832);
            this.subscription1.TabIndex = 5;
            // 
            // changeAccount1
            // 
            this.changeAccount1.BackColor = System.Drawing.Color.White;
            this.changeAccount1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.changeAccount1.Location = new System.Drawing.Point(0, 0);
            this.changeAccount1.Name = "changeAccount1";
            this.changeAccount1.Size = new System.Drawing.Size(1544, 832);
            this.changeAccount1.TabIndex = 4;
            // 
            // dashBoard1
            // 
            this.dashBoard1.BackColor = System.Drawing.Color.White;
            this.dashBoard1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashBoard1.Location = new System.Drawing.Point(0, 0);
            this.dashBoard1.MinimumSize = new System.Drawing.Size(44, 119);
            this.dashBoard1.Name = "dashBoard1";
            this.dashBoard1.Size = new System.Drawing.Size(1544, 832);
            this.dashBoard1.TabIndex = 3;
            // 
            // walletPnl1
            // 
            this.walletPnl1.BackColor = System.Drawing.Color.White;
            this.walletPnl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.walletPnl1.Location = new System.Drawing.Point(0, 0);
            this.walletPnl1.Name = "walletPnl1";
            this.walletPnl1.Size = new System.Drawing.Size(1544, 832);
            this.walletPnl1.TabIndex = 2;
            // 
            // cropsCrud1
            // 
            this.cropsCrud1.BackColor = System.Drawing.Color.White;
            this.cropsCrud1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cropsCrud1.Location = new System.Drawing.Point(0, 0);
            this.cropsCrud1.Name = "cropsCrud1";
            this.cropsCrud1.Size = new System.Drawing.Size(1544, 832);
            this.cropsCrud1.TabIndex = 1;
            // 
            // fieldCrud1
            // 
            this.fieldCrud1.BackColor = System.Drawing.Color.White;
            this.fieldCrud1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fieldCrud1.Location = new System.Drawing.Point(0, 0);
            this.fieldCrud1.Name = "fieldCrud1";
            this.fieldCrud1.Size = new System.Drawing.Size(1544, 832);
            this.fieldCrud1.TabIndex = 0;
            // 
            // btnReports
            // 
            this.btnReports.AccessibleName = "";
            this.btnReports.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReports.Animated = true;
            this.btnReports.AnimatedGIF = true;
            this.btnReports.BorderColor = System.Drawing.Color.White;
            this.btnReports.BorderRadius = 5;
            this.btnReports.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnReports.CheckedState.CustomBorderColor = System.Drawing.Color.White;
            this.btnReports.CheckedState.ForeColor = System.Drawing.Color.Navy;
            this.btnReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReports.DisabledState.BorderColor = System.Drawing.Color.Navy;
            this.btnReports.DisabledState.CustomBorderColor = System.Drawing.Color.Navy;
            this.btnReports.DisabledState.FillColor = System.Drawing.Color.Navy;
            this.btnReports.DisabledState.ForeColor = System.Drawing.Color.White;
            this.btnReports.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnReports.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.btnReports.ForeColor = System.Drawing.Color.White;
            this.btnReports.HoverState.BorderColor = System.Drawing.Color.White;
            this.btnReports.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.btnReports.HoverState.FillColor = System.Drawing.Color.White;
            this.btnReports.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(211)))), ((int)(((byte)(102)))));
            this.btnReports.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnReports.Image = ((System.Drawing.Image)(resources.GetObject("btnReports.Image")));
            this.btnReports.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnReports.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReports.Location = new System.Drawing.Point(21, 446);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(310, 45);
            this.btnReports.TabIndex = 15;
            this.btnReports.Text = "Reports";
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // reports1
            // 
            this.reports1.BackColor = System.Drawing.Color.White;
            this.reports1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reports1.Location = new System.Drawing.Point(0, 0);
            this.reports1.Name = "reports1";
            this.reports1.Size = new System.Drawing.Size(1544, 832);
            this.reports1.TabIndex = 6;
            // 
            // FarmerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1900, 893);
            this.Controls.Add(this.minBtnFarmer);
            this.Controls.Add(this.maxBtnFarmer);
            this.Controls.Add(this.closeBtnFarmer);
            this.Controls.Add(this.maxBtnFamer);
            this.Controls.Add(this.panelMainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(1280, 850);
            this.Name = "FarmerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FarmerForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelMainMenu.ResumeLayout(false);
            this.panelManagePpl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.maxBtnFamer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel panelMainMenu;
        private Guna.UI2.WinForms.Guna2Button btnManageCrops;
        private Guna.UI2.WinForms.Guna2Panel panelManagePpl;
        private Guna.UI2.WinForms.Guna2Button btnManageAdvisor;
        private Guna.UI2.WinForms.Guna2Button ManageStudent;
        private Guna.UI2.WinForms.Guna2Button btnManageField;
        private Guna.UI2.WinForms.Guna2Panel sidePanel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnHome;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Elipse elipseMenuPanel;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2ResizeForm ResizeFarmerForm;
        private Guna.UI2.WinForms.Guna2ImageButton minBtnFarmer;
        private Guna.UI2.WinForms.Guna2ImageButton maxBtnFarmer;
        private Guna.UI2.WinForms.Guna2ImageButton closeBtnFarmer;
        private Guna.UI2.WinForms.Guna2Button btnWallet;
        private Guna.UI2.WinForms.Guna2Button btnSettings;
        private Guna.UI2.WinForms.Guna2Panel maxBtnFamer;
        private UI.FarmerUI.walletPnl walletPnl1;
        private UI.FarmerUI.CropsCrud cropsCrud1;
        private UI.FarmerUI.FieldCrud fieldCrud1;
        private UI.FarmerUI.DashBoard dashBoard1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private UI.FarmerUI.changeAccount changeAccount1;
        private Guna.UI2.WinForms.Guna2Button btnSubscription;
        private UI.Components.Subscription subscription1;
        private Guna.UI2.WinForms.Guna2Button btnReports;
        private UI.Components.Reports reports1;
    }
}